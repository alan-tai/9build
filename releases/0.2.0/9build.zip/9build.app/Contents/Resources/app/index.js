require('babel-register');
require('./main.js');
